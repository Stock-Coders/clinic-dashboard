<footer class="footer">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-6 footer-copyright">
          <p class="mb-0">
            <?php echo $__env->make('layouts.dashboard.includes.copy-right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </p>
        </div>
        <div class="col-md-6">
            <span class="fw-bold">Contact Info. &rightarrow;</span>
            <a href="https://wa.me/+201061770559" target="_blank">
                
                <i class="fa fa-whatsapp f-20" aria-hidden="true"></i>
                WhatsApp
            </a>|
            <a href="https://www.instagram.com/codexsoftwareservices01/" target="_blank">
                
                <i class="fa fa-instagram f-20" aria-hidden="true"></i>
                Instagram
            </a>|
            <a href="https://www.facebook.com/codexsoftwareservices/" target="_blank">
                
                <i class="fa fa-facebook f-20" aria-hidden="true"></i>
                Facebook
            </a>|
            <a href="https://mail.google.com/mail/?view=cm&to=codexsoftwareservices01@gmail.com&subject=Your%20Subject&body=Your%20Message" target="_blank">
                
                <i class="fa fa-google f-20" aria-hidden="true"></i>
                Gmail
            </a>
        </div>
        
      </div>
    </div>
  </footer>
<?php /**PATH E:\laragon\www\Codex-Software-Services\clinic-dashboard\resources\views/layouts/dashboard/includes/footer.blade.php ENDPATH**/ ?>