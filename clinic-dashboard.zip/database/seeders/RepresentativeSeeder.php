<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Representative;

class RepresentativeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $representative = Representative::create([ //ID = 1
            'name'           => "representative_1",
            'phone'          => "03456113457",
        ]);

        $representative = Representative::create([ //ID = 2
            'name'           => "representative_2",
            'phone'          => "07823114723",
        ]);

        $representative = Representative::create([ //ID = 3
            'name'           => "representative_3",
            'phone'          => "06148006246",
        ]);

        $representative = Representative::create([ //ID = 4
            'name'           => "representative_4",
            'phone'          => "06453223141",
        ]);
    }
}
