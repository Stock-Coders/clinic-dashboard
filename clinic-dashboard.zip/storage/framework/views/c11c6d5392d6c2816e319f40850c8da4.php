<?php $__env->startSection('title'); ?> Results "<?php echo e($searchQuery); ?>" (<?php echo e($mergedResults->count()); ?>) <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <p><?php echo $__env->make('layouts.dashboard.includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></p>
    <div class="row">
      <!-- Zero Configuration  Starts-->
      <div class="col-sm-12">
        <div class="card">
          <div class="card-header">
            <h5>Results - <span class="bade badge-dark text-light px-1 py-0 rounded"><?php echo e($searchQuery); ?></span> (<?php echo e($mergedResults->count()); ?>)</h5>
            
            <div class="row">
                <div class="col-md-9">
                    <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a> / Search Results
                </div>
                
            </div>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="display" id="basic-1">
                <thead>
                  <tr>
                    <th>#</th>
                    <th class="text-center">ID</th>
                    <th class="text-center">Subject (Title/Name)</th>
                    <th class="text-center">Image</th>
                    <th class="text-center">Reference (Entity)</th>
                    <?php if(in_array($authUserEmail, $allowedUsersEmails)): ?>
                    <th class="text-center">Action</th>
                    <?php endif; ?>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $mergedResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($result->id); ?></td>
                    <td>
                        <?php if($result->getTable() == "users"): ?>
                            <?php echo e($result->username); ?>

                            (<span class="fw-bold text-primary"><?php echo e($result->email); ?></span>)
                            <br/>
                            <?php if($result->user_role != null): ?>
                                (<span class="fw-bold text-danger"><?php echo e(ucfirst($result->user_type)); ?></span> &rightarrow; <span class="fw-bold text-secondary"><?php echo e(ucfirst($result->user_role)); ?></span>)
                            <?php else: ?>
                                (<span class="fw-bold text-danger"><?php echo e(ucfirst($result->user_type)); ?></span>)
                            <?php endif; ?>
                        <?php elseif($result->getTable() == "patients"): ?>
                            <a class="text-decoration-underline fw-bold" href="<?php echo e(route('patients.show', [$result->id, $result->first_name])); ?>" target="_blank">
                                <?php echo e($result->first_name .' '. $result->last_name); ?>

                            </a>
                        <?php elseif($result->getTable() == "xrays"): ?>
                            <a class="text-decoration-underline fw-bold" href="<?php echo e(route('x-rays.show', $result->id)); ?>" target="_blank"><?php echo e($result->timing == "in_between" ? "In Between" : ucfirst($result->timing)); ?></a>
                            (<a class="text-decoration-underline fw-bold text-secondary" href="<?php echo e(route('patients.show', [$result->patient_id, $result->patient->first_name])); ?>" target="_blank"><?php echo e($result->patient->first_name .' '. $result->patient->last_name); ?></a>)
                        <?php elseif($result->getTable() == "representatives"): ?>
                            <?php echo e($result->name); ?>

                            <?php if($result->email != null): ?>
                            (<span class="fw-bold text-primary"><?php echo e($result->email); ?></span>)
                            <?php endif; ?>
                        <?php elseif($result->getTable() == "materials"): ?>
                            <?php echo e($result->title); ?>

                        <?php endif; ?>
                    </td>
                    <td class="image-td text-center">
                        <?php if($result->getTable() == "users"): ?>
                            <?php if(isset($result->profile->avatar)): ?>
                            <img src="<?php echo e(Storage::url($result->profile->avatar)); ?>" class="<?php if(!Storage::exists($result->profile->avatar)): ?> bg-warning p-2 rounded text-center text-dark <?php endif; ?>" alt="Image not found." width="80">
                            <?php else: ?>
                            
                            —
                            <?php endif; ?>
                        <?php elseif($result->getTable() == "patients"): ?>
                        <img src="<?php echo e(Storage::url($result->image)); ?>" alt="—" width="80">
                        <?php elseif($result->getTable() == "xrays"): ?>
                        <img src="<?php echo e(Storage::url($result->image)); ?>" alt="—" width="80">
                        <?php else: ?>
                        —
                        <?php endif; ?>
                    </td>
                    <th>
                        <?php if($result->getTable() == "users"): ?>
                            <a href="<?php echo e(route('users.UsersIndex')); ?>" class="text-decoration-underline fw-bold" target="_blank">
                                <?php echo e(ucfirst($result->getTable())); ?>

                            </a>
                        <?php elseif($result->getTable() == "patients"): ?>
                            <a href="<?php echo e(route('patients.index')); ?>" class="text-decoration-underline fw-bold" target="_blank">
                                <?php echo e(ucfirst($result->getTable())); ?>

                            </a>
                        <?php elseif($result->getTable() == "xrays"): ?>
                            <a href="<?php echo e(route('x-rays.index')); ?>" class="text-decoration-underline fw-bold" target="_blank">
                                X-rays
                            </a>
                        <?php elseif($result->getTable() == "representatives"): ?>
                            <a href="<?php echo e(route('representatives.index')); ?>" class="text-decoration-underline fw-bold" target="_blank">
                                <?php echo e(ucfirst($result->getTable())); ?>

                            </a>
                        <?php elseif($result->getTable() == "materials"): ?>
                            <a href="<?php echo e(route('materials.index')); ?>" class="text-decoration-underline fw-bold" target="_blank">
                                <?php echo e(ucfirst($result->getTable())); ?>

                            </a>
                        <?php endif; ?>
                    </th>
                    <?php if(in_array($authUserEmail, $allowedUsersEmails)): ?>
                    <th class="w-25" style="<?php if(auth()->user()->user_type == "developer" && $result->id != auth()->user()->id && $result->user_type == "developer"): ?> background-color: rgb(255, 204, 153); <?php endif; ?>">
                        <div class="d-flex justify-content-center">
                            <?php if($result->getTable() == "users"): ?>
                                <?php if(auth()->user()->user_type == "developer" && $result->user_type != "developer"): ?>
                                    <a class="btn btn-primary btn-md m-1 px-3" href="<?php echo e(route('users.edit', $result->id)); ?>"title="Edit (<?php echo e($result->username); ?>)">
                                        <i class="fa fa-edit f-18"></i>
                                    </a>
                                    <form action="<?php echo e(route('users.destroy', $result->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" onclick="return confirm('Are you sure that you want to delete (<?php echo e($result->username); ?>) user?');"title="Delete (<?php echo $result->username; ?>)" class="btn btn-danger btn-md m-1 px-3"><i class="fa fa-trash-o f-18"></i></button>
                                    </form>
                                <?php elseif(auth()->user()->user_type == "developer" && auth()->user()->id == $result->id): ?>
                                    <a class="btn btn-primary btn-md m-1 px-3" href="<?php echo e(route('users.edit', $result->id)); ?>"title="Edit (<?php echo e($result->username); ?>)">
                                        <i class="fa fa-edit f-18"></i>
                                    </a>
                                <?php else: ?>
                                    <div class="d-flex justify-content-center">
                                        <span class="text-center text-dark fw-bold fs-6"><i class="fa fa-lock f-30"></i></span> 
                                    </div>
                                <?php endif; ?>
                            <?php elseif($result->getTable() == "patients"): ?>
                                <a class="btn btn-warning text-dark btn-md m-1 px-3" href="<?php echo e(route('patients.show', $result->id)); ?>">
                                    <i class="icofont icofont-open-eye f-24"></i>
                                </a>
                                <a class="btn btn-primary btn-md m-1 px-3" href="<?php echo e(route('patients.edit', $result->id)); ?>">
                                    <i class="fa fa-edit f-18"></i>
                                </a>
                                <form action="<?php echo e(route('patients.destroy', $result->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" onclick="return confirm('Are you sure that you want to delete (<?php echo e($result->first_name . ' '. $result->last_name); ?>)\'s patient?');"title="Delete (<?php echo $result->first_name . ' ' . $result->last_name; ?>)" class="btn btn-danger btn-md m-1 px-3"><i class="fa fa-trash-o f-18"></i></button>
                                </form>
                            <?php elseif($result->getTable() == "xrays"): ?>
                                <a class="btn btn-warning text-dark btn-md m-1 px-3" href="<?php echo e(route('x-rays.show', $result->id)); ?>">
                                    <i class="icofont icofont-open-eye f-24"></i>
                                </a>
                                <a class="btn btn-primary btn-md m-1 px-3" href="<?php echo e(route('x-rays.edit', $result->id)); ?>">
                                    <i class="fa fa-edit f-18"></i>
                                </a>
                                <form action="<?php echo e(route('x-rays.destroy', $result->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" onclick="return confirm('Are you sure that you want to delete (<?php echo e($result->patient->first_name . ' '. $result->patient->last_name); ?>)\'s X-ray?');"title="Delete (<?php echo $result->patient->first_name.'\'s X-ray'; ?>)" class="btn btn-danger btn-md m-1 px-3"><i class="fa fa-trash-o f-18"></i></button>
                                </form>
                            <?php elseif($result->getTable() == "representatives"): ?>
                                <a class="btn btn-primary btn-md m-1 px-3" href="<?php echo e(route('representatives.edit', $result->id)); ?>">
                                    <i class="fa fa-edit f-18"></i>
                                </a>
                                <form action="<?php echo e(route('representatives.destroy', $result->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" onclick="return confirm('Are you sure that you want to delete (<?php echo e($result->name); ?>)\'s representative?');"title="Delete (<?php echo $result->name; ?>)" class="btn btn-danger btn-md m-1 px-3"><i class="fa fa-trash-o f-18"></i></button>
                                </form>
                            <?php elseif($result->getTable() == "materials"): ?>
                                
                                <a class="btn btn-primary btn-md m-1 px-3" href="<?php echo e(route('materials.edit', $result->id)); ?>">
                                    <i class="fa fa-edit f-18"></i>
                                </a>
                                <form action="<?php echo e(route('materials.destroy', $result->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" onclick="return confirm('Are you sure that you want to delete (<?php echo e($result->title); ?>)\'s material?');"title="Delete (<?php echo $result->title; ?>)" class="btn btn-danger btn-md m-1 px-3"><i class="fa fa-trash-o f-18"></i></button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </th>
                    <?php endif; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <!-- Zero Configuration  Ends-->
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<!-- Plugins css start-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/assets/dashboard/css/datatables.css')); ?>">
<style>
    .image-td {
        width: 20%;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- Plugins JS start-->
<script src="<?php echo e(asset('/assets/dashboard/js/datatable/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/dashboard/js/datatable/datatables/datatable.custom.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/dashboard/js/tooltip-init.js')); ?>"></script>
<!-- Plugins JS Ends-->
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\Codex-Software-Services\clinic-dashboard\resources\views/dashboard/search-results.blade.php ENDPATH**/ ?>