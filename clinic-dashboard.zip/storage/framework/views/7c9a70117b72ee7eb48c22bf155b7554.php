<?php $__env->startSection('title'); ?> All Treatments (<?php echo e(\App\Models\Treatment::count()); ?>) <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <p>
        <?php echo $__env->make('layouts.dashboard.includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </p>
    <div class="row">
      <!-- Zero Configuration  Starts-->
      <div class="col-sm-12">
        <div class="card">
          <div class="card-header">
            <h5>All Treatments (<?php echo e(\App\Models\Treatment::count()); ?>)</h5>
            
            <div class="row">
                <div class="col-md-9">
                    <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a> / Treatments
                </div>
                <div class="col-md-3">
                    <a href="<?php echo e(route('treatments.create')); ?>" class="btn btn-success-gradien">Create New Treatment</a>
                </div>
            </div>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="display" id="basic-1">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>ID</th>
                    <th>Patient</th>
                    <th>Procedure Name</th>
                    <th>Treatment Type</th>
                    <th>Doctor</th>
                    <th>Status</th>
                    <th>Cost (EGP)</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Notes</th>
                    
                    <th>Appointment ID</th>
                    <th>Created by</th>
                    <th>Updated by</th>
                    <th class="text-center">Print</th>
                    <th class="text-center">Action</th>
                  </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $treatments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treatment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $words = str_word_count($treatment->notes, 2); // Get an associative array of words
                    $limitedWords = array_slice($words, 0, 4); // Limit to the first 4 words
                    $limitedNotes = implode(' ', $limitedWords) . (count($words) >= 4 ? '...' : ''); // Combine and add "..." if there are equal or more words
                ?>
                <tr>
                    <th><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($treatment->id); ?></td>
                    <td>
                        
                        <?php if($treatment->prescription_id != null && $treatment->appointment_id == null): ?>
                        <a class="text-decoration-underline fw-bold" href="<?php echo e(route('patients.show', $treatment->prescription->appointment->patient_id)); ?>">
                            <?php echo e($treatment->prescription->appointment->patient->first_name .' '. $treatment->prescription->appointment->patient->last_name); ?>

                        </a>
                        <?php else: ?>
                        <a class="text-decoration-underline fw-bold" href="<?php echo e(route('patients.show', $treatment->appointment->patient_id)); ?>">
                            <?php echo e($treatment->appointment->patient->first_name .' '. $treatment->appointment->patient->last_name); ?>

                        </a>
                        <?php endif; ?>
                        
                    </td>
                    <td><?php echo e($treatment->procedure_name); ?></td>
                    <td><?php echo e(ucfirst($treatment->treatment_type)); ?></td>
                    <th>
                        <?php if($treatment->prescription_id != null && $treatment->appointment_id == null): ?>
                        
                            <?php echo e($treatment->prescription->appointment->doctor->profile->name ?? $treatment->prescription->appointment->doctor->username); ?>

                        
                        <?php else: ?>
                        
                            <?php echo e($treatment->appointment->doctor->profile->name ?? $treatment->appointment->doctor->username); ?>

                        
                        <?php endif; ?>
                    </th>
                    <td class="text-center">
                        <span class="
                        <?php if($treatment->status == "scheduled"): ?> badge badge-info
                        <?php elseif($treatment->status == "completed"): ?> badge badge-success
                        <?php else: ?> badge badge-danger
                        <?php endif; ?>">
                            <?php echo e(ucfirst($treatment->status)); ?>

                        </span>
                    </td>
                    <td class="text-center">
                        <span class="badge rounded-pill badge-dark f-12"><?php echo e($treatment->cost); ?></span>
                    </td>
                    <td><?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d', $treatment->treatment_date)->format('d-M-Y')); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($treatment->treatment_time)->format('h:i A')); ?></td>
                    <td><?php echo e($treatment->notes !== null ? $limitedNotes : '—'); ?></td>
                    
                    <td class="text-center">
                        <?php if($treatment->appointment_id != null): ?>
                            <?php echo e($treatment->appointment_id); ?> 
                        <?php else: ?>
                            <?php echo e($treatment->prescription->appointment_id); ?> 
                        <?php endif; ?>
                    </td>
                    <th><?php echo e($treatment->create_user->username); ?></th>
                    <th><?php echo e($treatment->update_user->username ?? '—'); ?></th>
                    <th class="text-center">
                        <a class="btn btn-info btn-xs px-2" href="<?php echo e(route('treatments.show.pdf', $treatment->id)); ?>">
                            <i class="icofont icofont-printer f-26"></i>
                        </a>
                    </th>
                    <th>
                        
                        <a class="btn btn-warning text-dark btn-md m-1 px-3" href="<?php echo e(route('treatments.show', $treatment->id)); ?>"title="<?php echo e($treatment->appointment_id != null && $treatment->prescription_id == null ? $treatment->appointment->patient->first_name : $treatment->prescription->appointment->patient->first_name); ?>'s treatment">
                            <i class="icofont icofont-open-eye f-24"></i>
                        </a>
                        
                        
                        <form action="<?php echo e(route('treatments.destroy', $treatment->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" onclick="return confirm('Are you sure that you want to delete (<?php echo e($treatment->procedure_name); ?>)?');"title="<?php echo e("Delete ($treatment->procedure_name )"); ?>" class="btn btn-danger btn-md m-1 px-3"><i class="fa fa-trash-o f-18"></i></button>
                        </form>
                    </th>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <!-- Zero Configuration  Ends-->
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<!-- Plugins css start-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/assets/dashboard/css/datatables.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- Plugins JS start-->
<script src="<?php echo e(asset('/assets/dashboard/js/datatable/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/dashboard/js/datatable/datatables/datatable.custom.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/dashboard/js/tooltip-init.js')); ?>"></script>
<!-- Plugins JS Ends-->
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\Codex-Software-Services\clinic-dashboard\resources\views/dashboard/treatments/index.blade.php ENDPATH**/ ?>