<div class="page-main-header">
    <div class="main-header-right row m-0">
      <div class="main-header-left">
        <div class="logo-wrapper"><a href="<?php echo e(route('dashboard')); ?>"><img class="light-logo img-fluid" width="160" src="<?php echo e(asset('/assets/dashboard/images/custom-images/logos/light_codex_full_logo.png')); ?>" alt=""></a></div>
        <div class="dark-logo-wrapper"><a href="<?php echo e(route('dashboard')); ?>"><img class="img-fluid" width="160" src="<?php echo e(asset('/assets/dashboard/images/custom-images/logos/dark_codex_full_logo.png')); ?>" alt=""></a></div>
        <?php if(auth()->guard()->check()): ?>
        <div class="toggle-sidebar"><i class="status_toggle middle" data-feather="align-center" id="sidebar-toggle"></i></div>
        <?php endif; ?>
      </div>
      <?php if(auth()->guard()->check()): ?>
      <div class="left-menu-header col">
        <ul>
          <li>
            <form action="<?php echo e(route('dashboard.search')); ?>" class="form-inline search-form">
              <div class="search-bg"><i class="fa fa-search"></i>
                <input class="form-control-plaintext" name="search_query" placeholder="Search for specific users, patients, x-rays, representatives or materials?" size="500">
              </div>
            </form><span class="d-sm-none mobile-search search-bg"><i class="fa fa-search"></i></span>
          </li>
        </ul>
      </div>
      <?php endif; ?>
      <div class="nav-right col pull-right right-menu p-0">
        <ul class="nav-menus">
          <li><a class="text-dark" href="#!" onclick="javascript:toggleFullScreen()"><i data-feather="maximize"></i></a></li>
          
          <?php if(auth()->guard()->check()): ?>
          <li class="onhover-dropdown">
            <div class="notification-box">
                <i data-feather="bell"></i>
                <?php
                    $newAppointments = \App\Models\Appointment::where('created_at', '>=', now()->subHours(24))
                                        ->where('doctor_id', auth()->user()->id) // Exclude appointments created by the current user
                                        ->where('create_user_id', '!=', auth()->user()->id)
                                        ->exists();

                    $newPayments = \App\Models\Payment::where('created_at', '>=', now()->subHours(24))
                                    ->where('create_user_id', '!=', auth()->user()->id) // Exclude payments created by the current user
                                    ->exists();
                ?>
                <?php if(auth()->user()->email === "doctor1@gmail.com" || auth()->user()->email === "doctor2@gmail.com" ||
                auth()->user()->email === "kareemtarekpk@gmail.com" || auth()->user()->email === "mr.hatab055@gmail.com" ||
                auth()->user()->email === "codexsoftwareservices01@gmail.com"): ?>
                    <?php if($newAppointments || $newPayments): ?>
                    <span class="dot-animated"></span>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <ul class="notification-dropdown onhover-show-div">
              <li>
                <?php
                    $appointments = \App\Models\Appointment::where('created_at', '>=', now()->subHours(24))
                                    ->where('doctor_id', auth()->user()->id) // Exclude appointments created by the current user
                                    ->where('create_user_id', '!=', auth()->user()->id)
                                    ->orderBy('created_at', 'desc')
                                    ->limit(4)
                                    ->get();
                    $payments = \App\Models\Payment::where('created_at', '>=', now()->subHours(24))
                                    ->where('create_user_id', '!=', auth()->user()->id) // Exclude payments created by the current user
                                    ->orderBy('created_at', 'desc')
                                    ->limit(4)
                                    ->get();
                     // Combine appointments and payments queries using union()
                    // $appointmentsAndPayments = $appointments->union($payments)->get();
                ?>
                <p class="f-w-700 mb-0">You have <span class="text-danger fw-bold"><?php echo e($appointments->count() + $payments->count()); ?></span> Notifications<span class="pull-right badge badge-primary badge-pill"><?php echo e($appointments->count() + $payments->count()); ?></span></p>
              </li>
              <li class="noti-primary">
                <div class="media">
                    
                  <div class="media-body">
                    
                    <span>
                        
                            <ul>
                                <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <div class="d-flex">
                                            <?php if($newAppointments): ?>
                                                <div>
                                                    <span class="notification-bg bg-light-secondary">
                                                        <i data-feather="activity"></i>
                                                    </span>
                                                </div>
                                            <?php elseif($newPayments): ?>
                                                <div>
                                                    <span class="notification-bg bg-light-success">
                                                        <i data-feather="money"></i>
                                                    </span>
                                                </div>
                                            <?php endif; ?>
                                            <?php if($newAppointments): ?>
                                                <div>
                                                    <a href="<?php echo e(route('appointments.show', $appointment->id)); ?>" class="text-decoration-underline">
                                                        <?php echo e($appointment->patient->first_name . ' ' . $appointment->patient->last_name ?? '-'); ?>

                                                    </a>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        
                    </span>
                  </div>
                </div>
              </li>
              
            </ul>
          </li>
          <?php endif; ?>
          <li>
            <div class="mode"><i class="fa fa-moon-o"></i></div>
          </li>
          
          <?php if(auth()->guard()->check()): ?>
            <li class="onhover-dropdown p-0">
                <a class="dropdown-item btn btn-primary-light" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.querySelector('#logout-form').submit();">
                    <i data-feather="log-out"></i>
                    Log Out
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                    </form>
                </a>
            </li>
          <?php endif; ?>
          <?php if(auth()->guard()->guest()): ?>
            <li class="onhover-dropdown p-0">
                <a class="dropdown-item btn btn-primary-light" href="<?php echo e(route('dashboard.login')); ?>">
                    <i data-feather="log-in"></i>
                    Log In
                </a>
            </li>
          <?php endif; ?>
        </ul>
      </div>
      <div class="d-lg-none mobile-toggle pull-right w-auto"><i data-feather="more-horizontal"></i></div>
    </div>
  </div>
<?php /**PATH E:\laragon\www\Codex-Software-Services\clinic-dashboard\resources\views/layouts/dashboard/includes/header.blade.php ENDPATH**/ ?>