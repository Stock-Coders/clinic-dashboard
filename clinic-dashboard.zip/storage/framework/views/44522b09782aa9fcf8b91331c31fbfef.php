<?php $__env->startSection('title'); ?>
<?php if($treatment->prescription_id != null && $treatment->appointment_id == null): ?>
    <?php echo e($treatment->prescription->appointment->patient->first_name .' '. $treatment->prescription->appointment->patient->last_name); ?>

<?php else: ?>
    <?php echo e($treatment->appointment->patient->first_name .' '. $treatment->appointment->patient->last_name); ?>

<?php endif; ?>
's
treatment (ID: <?php echo e($treatment->id); ?>)
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-12">
        <div class="print-btn-container mt-3">
            <div class="d-flex justify-content-end">
                <button class="btn btn-secondary fw-bold mx-3" id="print-btn" onclick="printPage();">طباعة</button>
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-dark fw-bold" id="print-btn">ارجع للخلف <i class="icofont icofont-arrow-right"></i></a>
            </div>
        </div>
        <div class="card shadow mb-4 mt-3">
          <div class="card-body" dir="rtl">
            <div class="row">
              <div class="col-md-12">
                
                <div class="container-fluid">
                    <div class="row">
                      <div class="col-sm-12">
                        
                        <div class="card">
                            <div class="d-flex flex-row-reverse justify-content-between p-2" style="background-color: rgb(235, 241, 252);">
                                <div class="p-3">
                                    <img src="<?php echo e(asset('assets/dashboard/images/custom-images/logos/light_codex_logo.png')); ?>" alt="codex_logo" width="100">
                                </div>
                                <div id="clinic-logo">
                                    <img src="<?php echo e(asset('assets/dashboard/images/custom-images/logos/teeth-logo.png')); ?>" alt="clinic_logo" width="200">
                                </div>
                                <div class="text-center">
                                    <span class="h5">دكتور</span>
                                    <p><h1>محمد قدري فايد</h1></p>
                                    <p id="english-name" class="h5">Dr. Mohamed Qadri Fayed</p>
                                    <h5>اخصائي طب و جراحة الفم و الأسنان</h5>
                                </div>
                            </div>
                            <div class="card-header pb-0">
                                
                                
                            </div>
                            <div class="card-body border border-2 border-dark">
                                <h1 class="text-center pb-4">جلسة العلاج (Treatment)</h1>
                                <?php if($treatment->prescription_id != null && $treatment->appointment_id == null): ?>
                                <p><span class="fw-bold text-decoration-underline">المريض:</span> <span class="badge bg-success fs-5"><?php echo e($treatment->prescription->appointment->patient->first_name .' '. $treatment->prescription->appointment->patient->last_name); ?></span></p>
                                <p><span class="text-primary fw-bold text-decoration-underline">الدكتور:</span> <span class="badge bg-info fs-5"><?php echo e($treatment->prescription->appointment->doctor->profile->name ?? $treatment->prescription->appointment->doctor->username); ?></span> </p>
                                <?php else: ?>
                                <p><span class="fw-bold text-decoration-underline">المريض:</span> <span class="badge bg-success fs-5"><?php echo e($treatment->appointment->patient->first_name .' '. $treatment->appointment->patient->last_name); ?></span></p>
                                <p><span class="text-primary fw-bold text-decoration-underline">الدكتور:</span> <span class="badge bg-info fs-5"><?php echo e($treatment->appointment->doctor->profile->name ?? $treatment->appointment->doctor->username); ?></span> </p>
                                <?php endif; ?>
                                <h5><span class="text-decoration-underline">أسم الإجراء:</span>
                                    <?php echo e($treatment->procedure_name); ?>

                                </h5>
                                <p>
                                    <span class="text-decoration-underline">نوع العلاج:</span> <span><?php echo e(ucfirst($treatment->treatment_type)); ?></span>
                                </p>
                                <p>
                                    <span class="text-decoration-underline">الحالة:</span>
                                    <span class="
                                    <?php if($treatment->status == "scheduled"): ?> badge bg-info text-dark
                                    <?php elseif($treatment->status == "completed"): ?> badge bg-success
                                    <?php else: ?> badge bg-danger
                                    <?php endif; ?>">
                                        <?php if($treatment->status == "scheduled"): ?>
                                        تم جدولته
                                        <?php elseif($treatment->status == "completed"): ?>
                                        منتهى
                                        <?php else: ?>
                                        ملغى
                                        <?php endif; ?>
                                    </span>
                                </p>
                                <p>
                                    <span class="text-decoration-underline">التاريخ:</span> <?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d', $treatment->treatment_date)->format('d-M-Y')); ?>

                                    <br/>
                                    <span class="text-decoration-underline">الوقت:</span> <?php echo e(\Carbon\Carbon::parse($treatment->treatment_time)->format('h:i A')); ?>

                                </p>
                                <p>
                                    <span class="bg-warning rounded-pill p-2 text-dark fw-bold h6">
                                        ملحوظات:
                                        <i class="icofont icofont-arrow-left f-18"></i>
                                    </span>
                                    <?php if($treatment->notes != null): ?>
                                    <p><?php echo e($treatment->notes); ?></p>
                                    <?php else: ?>
                                    <p class="text-danger">N/A</p>
                                    <?php endif; ?>
                                </p>
                                <hr/>
                                <p>
                                    <span class="text-decoration-underline">المبلغ (ج.م):</span> <span class="badge bg-dark text-light fs-6"> <?php echo e($treatment->cost); ?></span>
                                </p>
                            </div>
                        </div>
                        <div class="text-center mt-2">
                            <span class="h6">
                                دمياط - فارسكور - امتداد مركز الشرطة - خلف صيدليه الديب
                            </span>
                            <i class="icofont icofont-location-pin fs-5"></i>
                            <p class="mt-1">
                                <i class="icofont icofont-phone fs-5"></i>
                                +20 015 58 69 60 72
                            </p>
                        </div>
                        <div class="text-center">
                            <?php echo $__env->make('layouts.dashboard.includes.copy-right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                      </div>
                    </div>
                  </div>
                
              </div> <!-- /.col -->
            </div>
          </div>
        </div> <!-- / .card -->
      </div> <!-- .col-12 -->
    </div> <!-- .row -->
  </div> <!-- .container-fluid -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    @media print {
        .print-btn-container {
            display: none;
        }
    }

    #english-name {
        opacity: 50%;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function printPage() {
        event.preventDefault();
        window.print();
    }

    document.oncontextmenu = () => { //"Right Click" -> of mouse
        // alert("Sorry! This action isn't allowed.");
        return false;
    }

    document.onkeydown = (e) => {
        if(e.ctrlKey && e.key == 'u' || e.ctrlKey && e.key == 'U'){   //"ctrl + u" OR "ctrl + U" -> for viewing page source
            // alert("Sorry! You can't view the page source.");
            return false;
        }
        if(e.key == 'F12'){   //"F12" -> for page's inspect element
            // alert("Sorry! You can't inspect element for this page.");
            return false;
        }
        if(e.ctrlKey && e.shiftKey && e.key == 'c' || e.ctrlKey && e.shiftKey && e.key == 'C'){   //"ctrl + shift + c" OR "ctrl + shift + C" -> for page's inspect element
            // alert("Sorry! You can't inspect element for this page.");
            return false;
        }
        // if(e.ctrlKey && e.key == 'c' || e.ctrlKey && e.key == 'C'){   //"ctrl + c" OR "ctrl + C" -> for copying
        //     // alert("Sorry! You can't view the page source.");
        //     return false;
        // }
        if(e.ctrlKey && e.key == 'v' || e.ctrlKey && e.key == 'V'){   //"ctrl + v" OR "ctrl + V" -> for pasting
            // alert("Sorry! You can't view the page source.");
            return false;
        }
        // if(e.ctrlKey && e.key == 'p' || e.ctrlKey && e.key == 'P'){   //"ctrl + v" OR "ctrl + V" -> for printing
        //     // alert("Sorry! You can't open the print page.");
        //     return false;
        // }
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard.pdf-export-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\Codex-Software-Services\clinic-dashboard\resources\views/dashboard/treatments/pdf/show.blade.php ENDPATH**/ ?>