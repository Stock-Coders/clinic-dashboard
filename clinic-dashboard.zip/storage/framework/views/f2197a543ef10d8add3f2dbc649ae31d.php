<?php
    // Get the current year
    $currentYear = date('Y');
    // Set your specific year (e.g., the year of establishment)
    $establishmentYear = 2023; // Replace with your desired establishment year
    // Ensure the copyright year does not exceed the current year
    $copyrightYear = ($establishmentYear > $currentYear) ? $currentYear : $establishmentYear;
?>
<span class="<?php if(Route::is('telescope')): ?> text-warning font-weight-bold <?php else: ?> text-primary fw-bold <?php endif; ?>"><?php echo e(env('APP_NAME')); ?></span>
- Copyright © <?php echo e($copyrightYear); ?>-<?php echo e($copyrightYear + 1); ?>

<span class="<?php if(Route::is('telescope')): ?> text-warning font-weight-bold <?php else: ?> text-primary fw-bold <?php endif; ?>">Codex Software Services &trade;</span>
(Software Company).<?php if(!Route::is('dashboard.login') && !Route::is('dashboard.register') && !Route::is('telescope') && !Route::is('dashboard.debugging') && !Route::is('*pdf*')): ?> <br/> <?php endif; ?> All rights reserved.
<?php /**PATH E:\laragon\www\Codex-Software-Services\clinic-dashboard\resources\views/layouts/dashboard/includes/copy-right.blade.php ENDPATH**/ ?>