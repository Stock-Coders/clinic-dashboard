<?php if(session()->has('success')): ?>
<div class="alert alert-success text-center w-75 mx-auto" id="alert-success-message">
    <p class="position-absolute top-0 end-0">
        <span class="close-btn f-30" onclick="dismissMessage('alert-success-message');"><i class="icofont icofont-ui-close"></i></span>
    </p>
    <?php echo e(session()->get('success')); ?>

</div>
<?php elseif(session()->has('warning')): ?>
<div class="alert alert-warning text-center fw-bold text-dark w-75 mx-auto" id="alert-warning-message">
    <p class="position-absolute top-0 end-0">
        <span class="close-btn f-30" onclick="dismissMessage('alert-warning-message');"><i class="icofont icofont-ui-close"></i></span>
    </p>
    <?php echo e(session()->get('warning')); ?>

</div>
<?php elseif(session()->has('error')): ?>
<div class="alert alert-danger text-center w-75 mx-auto" id="alert-danger-message">
    <p class="position-absolute top-0 end-0">
        <span class="close-btn f-30" onclick="dismissMessage('alert-danger-message');"><i class="icofont icofont-ui-close"></i></span>
    </p>
    <?php echo e(session()->get('error')); ?>

</div>
<?php endif; ?>
<?php /**PATH E:\laragon\www\Codex-Software-Services\clinic-dashboard\resources\views/layouts/dashboard/includes/alert.blade.php ENDPATH**/ ?>