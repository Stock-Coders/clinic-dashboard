<?php $__env->startSection('title', "Treatment (ID: $treatment->id)"); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-12">
        <div class="card shadow mb-4">
          <div class="card-header">
            <div class="d-flex justify-content-between">
                <?php if($treatment->prescription_id != null && $treatment->treatment_id == null): ?>
                    <div class="d-flex align-items-center">
                        Add Last Visit For&nbsp;<span class="text-success fw-bold"><?php echo e($treatment->prescription->appointment->patient->first_name); ?></span>?
                        <a href="<?php echo e(route('patients.lastVisitsCreate', $treatment->prescription->appointment->patient->id)); ?>"><i class="icofont icofont-meeting-add text-success f-60"></i><i class="icon-hand-point-up f-16"></i></a>
                    </div>
                    <div class="d-flex align-items-center">
                        Print&nbsp;
                        <a href="<?php echo e(route('treatments.show.pdf', $treatment->id)); ?>"><i class="icofont icofont-printer f-40"></i><i class="icon-hand-point-up f-16"></i></a>
                    </div>
                    <div class="d-flex align-items-center">
                        Add X-ray For&nbsp;<span class="text-warning fw-bold"><?php echo e($treatment->prescription->appointment->patient->first_name); ?></span>?
                        <a href="<?php echo e(route('patient.x-rays.create', $treatment->prescription->appointment->patient->id)); ?>"><i class="icofont icofont-tooth text-warning f-40"></i><i class="icon-hand-point-up f-16"></i></a>
                    </div>
                <?php else: ?>
                    <div class="d-flex align-items-center">
                        Add Last Visit For&nbsp;<span class="text-success fw-bold"><?php echo e($treatment->appointment->patient->first_name); ?></span>?
                        <a href="<?php echo e(route('patients.lastVisitsCreate', $treatment->appointment->patient->id)); ?>"><i class="icofont icofont-meeting-add text-success f-60"></i><i class="icon-hand-point-up f-16"></i></a>
                    </div>
                    <div class="d-flex align-items-center">
                        Print&nbsp;
                        <a href="<?php echo e(route('treatments.show.pdf', $treatment->id)); ?>"><i class="icofont icofont-printer f-40"></i><i class="icon-hand-point-up f-16"></i></a>
                    </div>
                    <div class="d-flex align-items-center">
                        Add X-ray For&nbsp;<span class="text-warning fw-bold"><?php echo e($treatment->appointment->patient->first_name); ?></span>?
                        <a href="<?php echo e(route('patient.x-rays.create', $treatment->appointment->patient->id)); ?>"><i class="icofont icofont-tooth text-warning f-40"></i><i class="icon-hand-point-up f-16"></i></a>
                    </div>
                <?php endif; ?>
            </div>
            
            <strong class="card-title">
                <p class="fs-5"><span class="text-decoration-underline">Treatment ID:</span> <span class="badge rounded-pill badge-dark"><?php echo e($treatment->id); ?></span></p>
                <?php if($treatment->prescription_id != null && $treatment->treatment_id == null): ?>
                    <p class="fs-5"><span class="text-decoration-underline">Patient ID:</span> <span class="badge rounded-pill badge-dark"><?php echo e($treatment->prescription->appointment->patient->id); ?></span></p>
                    <p class="fs-5"><span class="text-decoration-underline">Patient Full Name:</span> <span style="background-color: rgb(235, 235, 235);" class="text-dark fw-bold p-1 rounded"><?php echo e($treatment->prescription->appointment->patient->first_name .' '. $treatment->prescription->appointment->patient->last_name); ?></span></p>
                <?php else: ?>
                    <p class="fs-5"><span class="text-decoration-underline">Patient ID:</span> <span class="badge rounded-pill badge-dark"><?php echo e($treatment->appointment->patient->id); ?></span></p>
                    <p class="fs-5"><span class="text-decoration-underline">Patient Full Name:</span> <span style="background-color: rgb(235, 235, 235);" class="text-dark fw-bold p-1 rounded"><?php echo e($treatment->appointment->patient->first_name .' '. $treatment->appointment->patient->last_name); ?></span></p>
                <?php endif; ?>
            </strong>
            <div class="d-flex justify-content-center">
                <?php $patientImage = $treatment->prescription_id != null && $treatment->treatment_id == null ? $treatment->prescription->appointment->patient->image : $treatment->appointment->patient->image; ?>
                <img src='<?php echo e(asset("/assets/dashboard/images/custom-images/patients/images/$patientImage")); ?>' alt="Patient Image?" width="200">
            </div>
          </div>
          <div class="card-body">
            <div class="row">
              <div class="col-md-12">
                
                <div class="container-fluid">
                    <div class="row">
                      <div class="col-sm-12">
                        <div class="mb-1">
                            <?php if($treatment->prescription_id != null && $treatment->treatment_id == null): ?>
                            <a class="text-primary fw-bold text-decoration-underline" href="<?php echo e(route('treatmentsOfPatient.showIndex', $treatment->prescription->appointment->patient->id)); ?>">Click here</a> to see all the <span class="fw-bold">treatments</span> of the current patient.
                            <?php else: ?>
                            <a class="text-primary fw-bold text-decoration-underline" href="<?php echo e(route('treatmentsOfPatient.showIndex', $treatment->appointment->patient->id)); ?>">Click here</a> to see all the <span class="fw-bold">treatments</span> of the current patient.
                            <?php endif; ?>
                        </div>
                        <div class="card">
                            <div class="card-header pb-0">
                                <h5><span class="text-decoration-underline">Procedure Name:</span> <?php echo e($treatment->procedure_name); ?></h5>
                                <p>
                                    <span class="text-decoration-underline">Treatment Type:</span> <span class="text-muted"><?php echo e(ucfirst($treatment->treatment_type)); ?></span>
                                </p>
                            </div>
                            <div class="card-body">
                                <p>
                                    <span class="text-primary fw-bold text-decoration-underline">Doctor:</span>
                                    <?php if($treatment->prescription_id != null && $treatment->treatment_id == null): ?>
                                        <?php echo e($treatment->prescription->appointment->doctor->username); ?>

                                    <?php else: ?>
                                        <?php echo e($treatment->appointment->doctor->username); ?>

                                    <?php endif; ?>
                                </p>
                                <p><span class="text-decoration-underline">Status:</span>
                                    <span class="
                                    <?php if($treatment->status == "scheduled"): ?> badge badge-info
                                    <?php elseif($treatment->status == "completed"): ?> badge badge-success
                                    <?php else: ?> badge badge-danger
                                    <?php endif; ?>">
                                        <?php echo e(ucfirst($treatment->status)); ?>

                                    </span>
                                </p>
                                <p>
                                    <span class="text-decoration-underline">Date:</span> <?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d', $treatment->treatment_date)->format('d-M-Y')); ?>

                                    <br/>
                                    <span class="text-decoration-underline">Time:</span> <?php echo e(\Carbon\Carbon::parse($treatment->treatment_time)->format('h:i A')); ?>

                                </p>
                                <p>
                                    <span class="bg-warning rounded-pill p-2 text-dark fw-bold h6">Notes <i class="icofont icofont-arrow-right f-18"></i></span>
                                    <?php if($treatment->notes != null): ?>
                                    <span><?php echo e($treatment->notes); ?></span>
                                    <?php else: ?>
                                    <span class="text-danger">N/A</span>
                                    <?php endif; ?>
                                </p>
                                <hr/>
                                <p>
                                    <span class="text-decoration-underline">Cost (EGP):</span> <span class="badge badge-dark text-light"> <?php echo e($treatment->cost); ?></span>
                                </p>
                            </div>
                        </div>
                      </div>
                    </div>
                  </div>
                
              </div> <!-- /.col -->
            </div>
          </div>
        </div> <!-- / .card -->
      </div> <!-- .col-12 -->
    </div> <!-- .row -->
  </div> <!-- .container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\Codex-Software-Services\clinic-dashboard\resources\views/dashboard/treatments/show.blade.php ENDPATH**/ ?>