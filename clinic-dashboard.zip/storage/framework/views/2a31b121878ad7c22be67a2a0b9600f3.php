<header class="main-nav">
    
    <div class="sidebar-user text-center"><a class="setting-primary" href="<?php echo e(route('users.edit', auth()->user()->id)); ?>"><i data-feather="settings"></i></a><img class="img-100 rounded-circle" src="<?php echo e(isset(auth()->user()->profile->avatar) != null ? Storage::url(auth()->user()->profile->avatar) : asset('/assets/dashboard/images/dashboard/no-avatar.png')); ?>" alt="">
      
        <a href="<?php echo e(route('authUserProfileView', [auth()->user()->username])); ?>">
            <h6 class="mt-3 f-14 f-w-600"><?php echo e(auth()->user()->profile->name ?? auth()->user()->username); ?></h6>
        </a>
      <p class="mb-0 font-roboto"><?php echo e(auth()->user()->user_role !== null ? ucfirst(auth()->user()->user_role) : "N/A"); ?></p>
      
    </div>
    <nav>
      <div class="main-navbar">
        <div class="left-arrow" id="left-arrow"><i data-feather="arrow-left"></i></div>
        <div id="mainnav">
          <ul class="nav-menu custom-scrollbar">
            <li class="back-btn">
              <div class="mobile-back text-end"><span>Back</span><i class="fa fa-angle-right ps-2" aria-hidden="true"></i></div>
            </li>
            <li class="sidebar-main-title">
              <div class="text-center mt-0">
                <h6><?php echo e(ucfirst(auth()->user()->user_type)); ?>s Dashboard</h6>
              </div>
            </li>
            <li class="dropdown"><a class="nav-link" href="<?php echo e(route('dashboard')); ?>"><i data-feather="home"></i><span>Dashboard</span></a></li>

            

            <?php if(auth()->user()->user_type === "doctor" || auth()->user()->user_type === "employee" || auth()->user()->user_type === "developer"): ?>
                
                <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><i data-feather="users"></i><span>Users</span></a>
                    <ul class="nav-submenu menu-content">
                        <li>
                            <a href="<?php echo e(route('users.UsersIndex')); ?>">
                                All Users
                                <?php if(auth()->user()->email === "kareemtarekpk@gmail.com" || auth()->user()->email === "mr.hatab055@gmail.com" ||
                                auth()->user()->email === "codexsoftwareservices01@gmail.com"): ?>
                                    (<?php echo e(\App\Models\User::count()); ?>)
                                <?php else: ?>
                                    (<?php echo e(\App\Models\User::whereNotIn('user_type', ['developer'])->count()); ?>)
                                <?php endif; ?>
                            </a>
                        </li>
                        <li><a href="<?php echo e(route('users.DoctorsIndex')); ?>">All Doctors (<?php echo e(\App\Models\User::ofType('doctor')->count()); ?>)</a></li>
                        <li><a href="<?php echo e(route('users.EmployeesIndex')); ?>">All Employees (<?php echo e(\App\Models\User::ofType('employee')->count()); ?>)</a></li>
                        <?php if(auth()->user()->email === "kareemtarekpk@gmail.com" || auth()->user()->email === "mr.hatab055@gmail.com" ||
                        auth()->user()->email === "codexsoftwareservices01@gmail.com"): ?>
                            <li><a href="<?php echo e(route('users.DevelopersIndex')); ?>">All Developers (<?php echo e(\App\Models\User::ofType('developer')->count()); ?>)</a></li>
                        <?php endif; ?>
                        <?php if(auth()->user()->email === "doctor1@gmail.com" || auth()->user()->email === "doctor2@gmail.com" ||
                        auth()->user()->email === "kareemtarekpk@gmail.com" || auth()->user()->email === "mr.hatab055@gmail.com" ||
                        auth()->user()->email === "codexsoftwareservices01@gmail.com"): ?>
                            <li><a href="<?php echo e(route('users.create')); ?>">Create User</a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                
                
                <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><i data-feather="user"></i><span>Patients</span></a>
                    <ul class="nav-submenu menu-content">
                        <li><a href="<?php echo e(route('patients.index')); ?>">All Patients (<?php echo e(\App\Models\Patient::count()); ?>)</a></li>
                        <li><a href="<?php echo e(route('patients.lastVisitsIndex')); ?>"><i class="icofont icofont-ui-calendar f-20"></i> Last Visits (<?php echo e(\App\Models\LastVisit::count()); ?>)</a></li>
                        <li><a href="<?php echo e(route('x-rays.index')); ?>"><i class="icofont icofont-tooth f-20"></i> X-rays (<?php echo e(\App\Models\XRay::count()); ?>)</a></li>
                        <li><a href="<?php echo e(route('analyses.index')); ?>"><i class="icofont icofont-file-alt f-20"></i> Analyses (<?php echo e(\App\Models\Analysis::count()); ?>)</a></li>
                        <li><a href="<?php echo e(route('medical-histories.index')); ?>"><i class="icofont icofont-history f-20"></i> Medical Histories (<?php echo e(\App\Models\MedicalHistory::count()); ?>)</a></li>
                        <li><a href="<?php echo e(route('patients.create')); ?>">Create Patient</a></li>
                    </ul>
                </li>
                
                
                <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><i data-feather="aperture"></i><span>Representatives</span></a>
                    <ul class="nav-submenu menu-content">
                        <li><a href="<?php echo e(route('representatives.index')); ?>">All Representatives (<?php echo e(\App\Models\Representative::count()); ?>)</a></li>
                        <?php if(auth()->user()->email === "doctor1@gmail.com" || auth()->user()->email === "doctor2@gmail.com" ||
                        auth()->user()->email === "kareemtarekpk@gmail.com" || auth()->user()->email === "mr.hatab055@gmail.com" ||
                        auth()->user()->email === "codexsoftwareservices01@gmail.com"): ?>
                            <li><a href="<?php echo e(route('representatives.create')); ?>">Create Representative</a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                
                
                <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><i data-feather="plus-square"></i><span>Materials</span></a>
                    <ul class="nav-submenu menu-content">
                        <li><a href="<?php echo e(route('materials.index')); ?>">All Materials (<?php echo e(\App\Models\Material::count()); ?>)</a></li>
                        <?php if(auth()->user()->email === "doctor1@gmail.com" || auth()->user()->email === "doctor2@gmail.com" || auth()->user()->email === "kareemtarekpk@gmail.com" || auth()->user()->email === "mr.hatab055@gmail.com" || auth()->user()->email === "codexsoftwareservices01@gmail.com"): ?>
                        <li><a href="<?php echo e(route('materials.create')); ?>">Create Material</a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                
                
                <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><i data-feather="bell"></i><span>Appointments</span></a>
                    <ul class="nav-submenu menu-content">
                        <li><a href="<?php echo e(route('appointments.index')); ?>">All Appointments (<?php echo e(\App\Models\Appointment::count()); ?>)</a></li>
                        <li><a href="<?php echo e(route('appointments.create')); ?>">Create Appointment</a></li>
                        <?php if(auth()->user()->email === "doctor1@gmail.com" || auth()->user()->email === "doctor2@gmail.com" || auth()->user()->email === "kareemtarekpk@gmail.com" || auth()->user()->email === "mr.hatab055@gmail.com" ||
                        auth()->user()->email === "codexsoftwareservices01@gmail.com"): ?>
                        <li><a href="<?php echo e(route('appointments.trash')); ?>">All Trashed Appointment (<?php echo e(\App\Models\Appointment::onlyTrashed()->count()); ?>)</a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                
                
                <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><i data-feather="file-text"></i><span>Prescriptions</span></a>
                    <ul class="nav-submenu menu-content">
                        <li><a href="<?php echo e(route('prescriptions.index')); ?>">All Prescriptions (<?php echo e(\App\Models\Prescription::count()); ?>)</a></li>
                        <?php if(auth()->user()->user_type == "doctor"  || auth()->user()->email === "kareemtarekpk@gmail.com" || auth()->user()->email === "mr.hatab055@gmail.com" ||
                        auth()->user()->email === "codexsoftwareservices01@gmail.com"): ?>
                            <li><a href="<?php echo e(route('prescriptions.create')); ?>">Create Prescription</a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                
                
                <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><i data-feather="calendar"></i><span>Treatments</span></a>
                    <ul class="nav-submenu menu-content">
                        <li><a href="<?php echo e(route('treatments.index')); ?>">All Treatments (<?php echo e(\App\Models\Treatment::count()); ?>)</a></li>
                        <li><a href="<?php echo e(route('treatments.create')); ?>">Create Treatment</a></li>
                        <li><a href="<?php echo e(route('prescriptions-treatments.index')); ?>">All Treatments' Prescriptions (<?php echo e(\App\Models\PrescriptionTreatment::count()); ?>)</a></li>
                        <?php if(auth()->user()->user_type == "doctor"  || auth()->user()->email === "kareemtarekpk@gmail.com" || auth()->user()->email === "mr.hatab055@gmail.com" ||
                        auth()->user()->email === "codexsoftwareservices01@gmail.com"): ?>
                            <li><a href="<?php echo e(route('prescriptions-treatments.create')); ?>">Create Prescription for Treatment</a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                
                
                <?php if(auth()->user()->email === "doctor1@gmail.com" || auth()->user()->email === "doctor2@gmail.com" ||
                auth()->user()->email === "kareemtarekpk@gmail.com" || auth()->user()->email === "mr.hatab055@gmail.com" ||
                auth()->user()->email === "codexsoftwareservices01@gmail.com"): ?>
                    <li class="dropdown">
                        <a class="nav-link" href="<?php echo e(route('materials-treatments.index')); ?>"><i data-feather="grid"></i><span>Treatments' Materials</span></a>
                    </li>
                <?php endif; ?>
                
                
                <li class="dropdown"><a class="nav-link menu-title" href="javascript:void(0)"><i data-feather="database"></i><span>Payments</span></a>
                    <ul class="nav-submenu menu-content">
                        <li><a href="<?php echo e(route('payments.index')); ?>">All Payments (<?php echo e(\App\Models\Payment::count()); ?>)</a></li>
                        <li><a href="<?php echo e(route('payments.create')); ?>">Create Payment</a></li>
                    </ul>
                </li>
                

            <?php endif; ?>
            <li><a class="nav-link menu-title link-nav" href="javascript:void(0)"><i data-feather="headphones"></i><span>Support Ticket</span></a></li>
            <?php if(auth()->user()->email === "kareemtarekpk@gmail.com" || auth()->user()->email === "mr.hatab055@gmail.com" || auth()->user()->email === "codexsoftwareservices01@gmail.com"): ?>
            <li class="dropdown"><a class="nav-link" href="<?php echo e(route('dashboard.debugging')); ?>"><i data-feather="cpu"></i><span>Debugging Tools</span></a></li>
            <?php endif; ?>
          </ul>
        </div>
        <div class="right-arrow" id="right-arrow"><i data-feather="arrow-right"></i></div>
      </div>
    </nav>
  </header>
<?php /**PATH E:\laragon\www\Codex-Software-Services\clinic-dashboard\resources\views/layouts/dashboard/includes/sidebar.blade.php ENDPATH**/ ?>