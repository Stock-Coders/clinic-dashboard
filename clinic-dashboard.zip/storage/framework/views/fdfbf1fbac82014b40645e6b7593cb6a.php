<?php $__env->startSection('title'); ?> All Users (<?php echo e($users->count()); ?>) <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <p><?php echo $__env->make('layouts.dashboard.includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></p>
    <div class="row">
      <!-- Zero Configuration  Starts-->
      <div class="col-sm-12">
        <div class="card">
          <div class="card-header">
            <h5>All Users (<?php echo e($users->count()); ?>)</h5>
            
            <div class="row">
                <div class="col-md-9">
                    <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a> / <a href="<?php echo e(route('users.UsersIndex')); ?>">Users</a> / All Users
                </div>
                <?php if(auth()->user()->user_type != "employee"): ?>
                <div class="col-md-3">
                    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-success-gradien">Create New User</a>
                </div>
                <?php endif; ?>
            </div>
          </div>
          <div class="card-body">
            
            <div class="table-responsive">
              <table class="display" id="basic-1">
                <thead>
                  <tr>
                    <th>#</th>
                    
                    <th>Avatar</th>
                    <th>Username <?php if(in_array($authUserEmail, $developersEmails)): ?> (Profile) <?php endif; ?></th>
                    <th>Email</th>
                    
                    <th>Phone</th>
                    <th>User Type</th>
                    <th>User Role</th>
                    <th>Account Status</th>
                    <th>Registration Date/Time</th>
                    <th>Last Login Date/Time</th>
                    <th>Last Login IP</th>
                    <th>Created by</th>
                    <th>Updated by</th>
                    
                    <?php if(in_array($authUserEmail, $allowedUsersEmails)): ?>
                    <th>Edit / Delete</th>
                    <?php endif; ?>
                    <?php if(auth()->user()->user_type === "employee" || auth()->user()->user_type === "doctor" && (auth()->user()->email !== "doctor1@gmail.com" && auth()->user()->email !== "doctor2@gmail.com")): ?>
                    <th>Action</th>
                    <?php endif; ?>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th style="<?php if($user->email === 'doctor1@gmail.com' || $user->email === 'doctor2@gmail.com'): ?> color: black; background-color:beige; <?php elseif($user->user_type === 'developer'): ?> color: black; background-color: #3bbaff; <?php endif; ?>">
                        <?php echo e($loop->iteration); ?>

                    </th>
                    
                    <td>
                        <?php if(isset($user->profile->avatar)): ?>
                        <img src="<?php echo e(Storage::url($user->profile->avatar)); ?>" width="70">
                        <?php else: ?>
                        —
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if(in_array($authUserEmail, $developersEmails) && !in_array($user->email, $developersEmails)): ?>
                            <a class="text-decoration-underline fw-bold" href="<?php echo e(route('authUserProfileView', $user->username)); ?>" target="_blank"><?php echo e($user->username); ?></a>
                        <?php elseif($user->id === auth()->user()->id && !in_array($user->email, $developersEmails)): ?>
                            <a class="text-decoration-underline fw-bold" href="<?php echo e(route('authUserProfileView', $user->username)); ?>" target="_blank"><?php echo e($user->username); ?></a> (Profile)
                        <?php elseif($user->id === auth()->user()->id && in_array($user->email, $developersEmails)): ?>
                            <a class="text-decoration-underline fw-bold" href="<?php echo e(route('authUserProfileView', $user->username)); ?>" target="_blank"><?php echo e($user->username); ?></a>
                        <?php else: ?>
                            <?php echo e($user->username); ?>

                        <?php endif; ?>
                    </td>
                    <td><?php echo e($user->email); ?></td>
                    
                    <td><?php echo e($user->phone); ?></td>
                    <?php if($user->email === "doctor1@gmail.com" || $user->email === "doctor2@gmail.com"): ?>
                    <td style="background-color:beige; font-weight:bold;">
                        <span class="text-dark"><?php echo e(ucfirst($user->user_type)); ?></span> <span class="text-success">(Master)</span>
                    </td>
                    <?php else: ?>
                    <td><?php echo e(ucfirst($user->user_type)); ?></td>
                    <?php endif; ?>
                    <td><?php echo e($user->user_role === null ? '—' : ucfirst($user->user_role)); ?></td>
                    <td class="text-center">
                        <span class="
                        <?php if($user->account_status === "active"): ?> badge bg-success text-light
                        <?php elseif($user->account_status === "suspended"): ?> badge bg-warning text-dark
                        <?php else: ?> badge bg-info text-light
                        <?php endif; ?> fw-bold text-center f-12">
                            <?php echo e(ucfirst($user->account_status)); ?>

                        </span>
                    </td>
                    <td><?php echo e(\Carbon\Carbon::parse($user->registration_datetime)->tz('Africa/Cairo')->format('d-m-Y h:i A')); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($user->last_login_datetime)->tz('Africa/Cairo')->format('d-m-Y h:i A') ?? '—'); ?></td>
                    <td><?php echo e($user->last_login_ip ?? '—'); ?></td>
                    <td><?php echo e($user->create_user->username ?? '—'); ?></td>
                    <td><?php echo e($user->update_user->username ?? '—'); ?></td>
                    
                    <?php if(in_array($authUserEmail, $allowedUsersEmails)): ?>
                        <th style="<?php if((($user->email === "doctor1@gmail.com" || $user->email === "doctor2@gmail.com") && auth()->user()->id !== $user->id && auth()->user()->user_type === "doctor") ||
                        ($user->user_type === "developer" && auth()->user()->id !== $user->id && auth()->user()->user_type === "developer")): ?> background-color:rgb(255, 204, 153); <?php endif; ?>">
                            <?php if(($user->email === "doctor1@gmail.com" || $user->email === "doctor2@gmail.com") && auth()->user()->id !== $user->id &&
                            (auth()->user()->email !== "kareemtarekpk@gmail.com" && auth()->user()->email !== "mr.hatab055@gmail.com" &&
                            auth()->user()->email !== "codexsoftwareservices01@gmail.com")): ?>
                                <div class="d-flex justify-content-center">
                                    <span class="text-center text-dark fw-bold fs-6"><i class="fa fa-lock f-30"></i></span> 
                                </div>
                            <?php elseif((auth()->user()->email === "kareemtarekpk@gmail.com" || auth()->user()->email === "mr.hatab055@gmail.com" ||
                            auth()->user()->email === "codexsoftwareservices01@gmail.com") && auth()->user()->id !== $user->id && $user->user_type === "developer" &&
                            auth()->user()->user_type === "developer"): ?>
                                <div class="d-flex justify-content-center">
                                    <span class="text-center text-dark fw-bold fs-6"><i class="fa fa-lock f-30"></i></span> 
                                </div>
                            <?php else: ?>
                                <div class="d-flex <?php if(auth()->user()->id === $user->id): ?> justify-content-center <?php else: ?> justify-content-between <?php endif; ?>">
                                    <a class="<?php if(auth()->user()->id === $user->id): ?> btn btn-dark <?php else: ?> btn btn-primary <?php endif; ?> btn-md m-1 px-3" href="<?php echo e(route('users.edit', $user->id)); ?>" <?php if(auth()->user()->id === $user->id): ?> title="Edit your data" title="<?php echo e('Edit ('.$user->username.')'); ?>" <?php endif; ?>>
                                        <?php if(auth()->user()->id === $user->id): ?><i class="fa fa-user f-28" aria-hidden="true"></i><?php endif; ?>
                                        <i class="fa fa-edit f-18"></i>
                                    </a>
                                    <?php if(auth()->user()->id !== $user->id): ?>
                                        <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" onclick="return confirm('Are you sure that you want to delete (<?php echo e($user->username); ?>)?');" title="<?php echo e("Delete ($user->username)"); ?>" class="btn btn-danger btn-md m-1 px-3"><i class="fa fa-trash-o f-18"></i></button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </th>
                    <?php endif; ?>
                    <?php if(auth()->user()->user_type === "employee" || auth()->user()->user_type === "doctor" && (auth()->user()->email !== "doctor1@gmail.com" && auth()->user()->email !== "doctor2@gmail.com")): ?>
                    <th>
                        <div class="d-flex justify-content-center">
                            <?php if(auth()->user()->id === $user->id): ?>
                            <a class="btn btn-dark btn-md m-1 px-3" href="<?php echo e(route('users.edit', $user->id)); ?>" title="Edit your data">
                                <i class="fa fa-user f-28" aria-hidden="true"></i><i class="fa fa-edit f-18"></i>
                            </a>
                            <?php else: ?>
                                —
                            <?php endif; ?>
                        </div>
                    </th>
                    <?php endif; ?>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <!-- Zero Configuration  Ends-->
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<!-- Plugins css start-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/assets/dashboard/css/datatables.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- Plugins JS start-->
<script src="<?php echo e(asset('/assets/dashboard/js/datatable/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/dashboard/js/datatable/datatables/datatable.custom.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/dashboard/js/tooltip-init.js')); ?>"></script>
<!-- Plugins JS Ends-->
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\Codex-Software-Services\clinic-dashboard\resources\views/dashboard/users/indexes/all-users.blade.php ENDPATH**/ ?>