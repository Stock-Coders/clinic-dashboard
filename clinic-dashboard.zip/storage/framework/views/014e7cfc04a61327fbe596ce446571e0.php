<?php $xray = app('App\Models\XRay'); ?>
<?php $__env->startSection('title', 'Create X-ray'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
            <h4 class="card-title">Create X-ray for <a class="text-decoration-underline fw-bold" href="<?php echo e(route('patients.show', $patient->id)); ?>"><?php echo e($patient->first_name . ' ' . $patient->last_name); ?></a></h4>
            <div class="col-sm-12 col-xl-12 xl-100">
                <div class="card-header pb-0">
                    <span><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a> / <a href="<?php echo e(route('x-rays.index')); ?>">X-rays</a> / Create X-ray for <?php echo e($patient->first_name . ' ' . $patient->last_name); ?></span>
                </div>
                <div class="card-body">
                    <div class="tab-content" id="pills-tabContent">
                        <form action="<?php echo e(route('x-rays.store')); ?>" class="forms-sample" method="POST" id="alert-form" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo $__env->make('dashboard.x-rays.single.single-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <input type="submit" value="Add" class="btn btn-success btn-md px-4 fs-8 shadow border-2 border-dark rounded me-2">
                            <input type="reset" value="Reset" class="btn btn-light btn-md px-4 fs-8 shadow border-2 border-dark rounded">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\Codex-Software-Services\clinic-dashboard\resources\views/dashboard/x-rays/single/single-create.blade.php ENDPATH**/ ?>